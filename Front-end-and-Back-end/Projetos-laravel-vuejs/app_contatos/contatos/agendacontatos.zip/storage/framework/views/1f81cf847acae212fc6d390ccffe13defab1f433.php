<?php $__env->startSection('title', 'Listando todos os registros'); ?>
 
<?php $__env->startSection('content'); ?>
<h2>Lista de Contatos</h2>
<hr>
<div class="container">
    <table class="table table-bordered table-striped table-sm">
        <thead>
      <tr>
          <th>#</th>
          <th>Nome</th>
          <th>email</th>
          <th>telefone</th>
          <th>endereço</th>
          <th>facebook</th>
          <th>
        <a href="<?php echo e(route('customers.create')); ?>" class="btn btn-info btn-sm" >Novo</a>
          </th>
      </tr>
        </thead>
        <tbody>
      <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <tr>
          <td><?php echo e($customer->id); ?></td>
          <td><?php echo e($customer->name); ?></td>
          <td><?php echo e($customer->email); ?></td>
          <td><?php echo e($customer->phone); ?></td>
          <td><?php echo e($customer->address); ?></td>
          <td><?php echo e($customer->facebook); ?></td>
          <td>
        <a href="<?php echo e(route('customers.edit', ['id' => $customer->id])); ?>" class="btn btn-warning btn-sm">Editar</a>
        <form method="POST" action="<?php echo e(route('customers.destroy', ['id' => $customer->id])); ?>" style="display: inline" onsubmit="return confirm('Deseja excluir este registro?');" >
            <?php echo csrf_field(); ?>
            <input type="hidden" name="_method" value="delete" >
            <button class="btn btn-danger btn-sm">Excluir</button>
        </form>
          </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <tr>
          <td colspan="6">Nenhum registro encontrado para listar</td>
      </tr>
      <?php endif; ?>
        </tbody>
    </table>
    <?php echo e($customers->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>