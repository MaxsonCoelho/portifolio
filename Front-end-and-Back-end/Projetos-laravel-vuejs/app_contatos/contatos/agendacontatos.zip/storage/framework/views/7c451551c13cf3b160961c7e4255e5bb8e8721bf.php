<?php $__env->startSection('title', 'Registro'); ?>
 
<?php $__env->startSection('content'); ?>
<h1>Criação de contatos</h1>
<hr>
 
<div class="container">
 
 
    <?php if(isset($customer)): ?>
 
        <?php echo Form::model($customer, ['method' => 'put', 'route' => ['customers.update', $customer->id ], 'class' => 'form-horizontal']); ?>

 
    <?php else: ?>
 
        <?php echo Form::open(['method' => 'post','route' => 'customers.store', 'class' => 'form-horizontal']); ?>

 
    <?php endif; ?>
 
    <div class="card">
        <div class="card-header">
      <span class="card-title">
          <?php if(isset($customer)): ?>
        Editando contato #<?php echo e($customer->id); ?>

          <?php else: ?>
        Criando novo contato
          <?php endif; ?>
      </span>
        </div>
        <div class="card-body">
      <div class="form-row form-group">
 
          <?php echo Form::label('name', 'Nome', ['class' => 'col-form-label col-sm-2 text-right']); ?>

 
          <div class="col-sm-4">
 
        <?php echo Form::text('name', null, ['class' => 'form-control', 'placeholder'=>'Digite seu nome']); ?>

 
          </div>
 
      </div>
      <div class="form-row form-group">
 
          <?php echo Form::label('email', 'E-mail', ['class' => 'col-form-label col-sm-2 text-right']); ?>

 
          <div class="col-sm-4">
 
        <?php echo Form::text('email', null, ['class' => 'form-control', 'placeholder'=>'Digite seu e-mail']); ?>

 
          </div>
 
      </div>
      <div class="form-row form-group">
 
          <?php echo Form::label('phone', 'Telefone', ['class' => 'col-form-label col-sm-2 text-right']); ?>

 
          <div class="col-sm-4">
 
        <?php echo Form::text('phone', null, ['class' => 'form-control', 'placeholder'=>'Digite seu telefone']); ?>

 
          </div>
 
      </div>
      <div class="form-row form-group">
 
          <?php echo Form::label('address', 'Endereço', ['class' => 'col-form-label col-sm-2 text-right']); ?>

 
          <div class="col-sm-8">
 
        <?php echo Form::text('address', null, ['class' => 'form-control', 'placeholder'=>'Digite seu endereço']); ?>

 
          </div>
 
      </div>
      <div class="form-row form-group">
 
          <?php echo Form::label('facebook', 'Facebook', ['class' => 'col-form-label col-sm-2 text-right']); ?>

 
          <div class="col-sm-10">
 
        <?php echo Form::url('facebook', null, ['class' => 'form-control', 'placeholder'=>'Coloque aqui a url do seu facebook']); ?>

 
          </div>
 
      </div>
        </div>
        <div class="card-footer">
      <?php echo Form::button('cancelar', ['class'=>'btn btn-danger btn-sm', 'onclick' =>'windo:history.go(-1);']);; ?>

      <?php echo Form::submit(  isset($customer) ? 'atualizar' : 'criar', ['class'=>'btn btn-success btn-sm']); ?>

 
        </div>
    </div>
 
    <?php echo Form::close(); ?>

 
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>